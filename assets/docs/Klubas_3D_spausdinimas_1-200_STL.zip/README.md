# Karininku klubas - 3D spaudos rinkinys 1:200

Mastelis 1:200 (1 m = 5 mm). Visas modelis ~23 x 19 cm (su kiemu), aukstis ~7,5 cm. Spausdintuvo pagrindas 22 x 22 cm.
Kaisciai 2 mm skersmens, lizdai +0,2 mm tarpas. Apacios plokscios. Dalys sulietos (voxel 0,5 mm) - uzdaros ir vientisos (manifold).

| Failas | Spalva | Dalis | Matmenys mm (X x Y x Z) | Telpa 22x22 |
|---|---|---|---|---|
| 01a_pagrindas_A_pilka.stl | pilka | pagrindo plokste A su kiemu (3 mm) | 131.0 x 190.0 x 3.4 | taip |
| 01b_pagrindas_B_pilka.stl | pilka | pagrindo plokste B (3 mm) | 112.0 x 190.0 x 3.0 | taip |
| 02_sienos_A_smelio.stl | smelio | kairysis sparnas + centrinis korpusas su fasado apdaila | 120.0 x 99.5 x 77.8 | taip |
| 03_sienos_B_smelio.stl | smelio | jungtis + desinysis korpusas su fasado apdaila | 104.1 x 97.7 x 77.8 | taip |
| 04_stogas_A_pilka.stl | pilka | stogas virs A | 119.7 x 79.9 x 19.4 | taip |
| 05_stogas_B_pilka.stl | pilka | stogas virs B | 97.4 x 66.5 x 8.5 | taip |
| 06_kolonada_balkonai_balta.stl | balta | kolonada su terasa, balkonai su baliustradomis (baliustrai sulieti) | 165.6 x 49.3 x 35.6 | taip |
| 07_kaminai_plytu.stl | plytu | kaminai (klijuojami ant stogo) | 174.5 x 33.5 x 28.0 | taip |
| 08_langai_durys_tamsi.stl | tamsi | langu stiklai ir durys - iklotai i angas (pasirinktinai) | 218.2 x 90.7 x 51.6 | taip |
| 09_fontanas_balta.stl | balta | fontano baseinas su kolonele | 20.0 x 20.0 x 15.2 | taip |

## Surinkimo tvarka
1. Sujunkite pagrindo plokstes 01a ir 01b (horizontalus kaisciai).
2. Istatykite sienas 02 (A) ir 03 (B) i lizdus; siule ties centriniu korpusu suklijuokite.
3. Uzdekite kolonada ir balkonus 06.
4. Iklijuokite langu/duru iklotus 08 (pasirinktinai - galima tiesiog nudazyti).
5. Uzdekite stogus 04 ir 05, ant ju - kaminus 07.
6. Istatykite fontana 09 kieme.

Pastabos: smulkus baliustrai sulieti i vientisas tvoreles (1:200 jie butu ~0,7 mm). Fasado apdaila (lizenos, karnizai, apvadai) - sienu dalyje, dazoma baltai teptuku.
